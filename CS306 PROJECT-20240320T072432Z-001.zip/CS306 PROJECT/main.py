from connect import connectDB
from sample_movies import sample_movies
from TVshow_database import TVshow_database
from pymongo import errors
import tkinter as tk
from tkinter import *
from tkinter import simpledialog, messagebox, scrolledtext

# create connection

db = connectDB()


def user_prompt_creation():
    collection_name = tk.simpledialog.askstring("Create a Collection", "Please enter a name for the collection: ")
    if collection_name:
        createCollection(db, collection_name)


def collections_options():  # for inserting into a collection

    collections_options = db.list_collection_names()
    options_text = "\n".join([f"{i + 1}.{collection}" for i, collection in enumerate(collections_options)])
    collection_name = tk.simpledialog.askstring("Choose",
                                                f"Please write the name of the collection that you want to insert into: \n {options_text} ")
    if collection_name:
        try:
            # Converting the user's input to an index
            index = int(collection_name) - 1
            if 0 <= index < len(collections_options):
                selected_collection = collections_options[index]
                messagebox.showinfo("Selected", f"Selected collection: {selected_collection}")

                data = tk.simpledialog.askstring("Data",
                                                            f"Enter the data fields that you want to insert into {selected_collection} as a key : value pairs separated by commas")
                # Creating the user input into a proper dictionary
                if data:
                    pairs = data.split(";")
                    data_entries = {}
                    for pair in pairs:
                        key, values = pair.split(":")
                        key = key.strip()
                        values = [value.strip() for value in values.split(',')]
                        if key in data_entries:
                            # If yes, append the new values to the existing list
                            data_entries[key].extend(values)
                        else:
                            # If no, create a new list for the key
                            data_entries[key] = values

                    insert_into_collection(db, selected_collection, data_entries)
            else:
                messagebox.showinfo("Out of bounds", "Invalid selection. Please choose from the options.")
        except ValueError:
            messagebox.showinfo("Wrong format", "Invalid input. Please enter a number.")


def createCollection(database, collection_name):
    try:
        # if the connection doesn't exist create it
        if collection_name not in database.list_collection_names():
            database.create_collection(collection_name)
            # print(f"Collection {collection_name} created!")
            messagebox.showinfo("Collected Created", f"Collection {collection_name} created successfully!")

        elif collection_name in database.list_collection_names():
            messagebox.showinfo("Duplicate", "Connection already exists")

    except Exception as e:
        print("Error: ", e)


def insert_into_collection(database, collection_name, data):
    try:
        # Access the specified collection
        collection = database[collection_name]

        # insert the data into the collection
        result = collection.insert_one(data)
        # Print the inserted document ID
        messagebox.showinfo("Inserted successfully.", f"Your data has been inserted. Inserted document ID: {result.inserted_id}")
        # print(f"Inserted document ID: {result.inserted_id}")

    except Exception as e:
        messagebox.showinfo("Failed to insert", f"Could not insert: {e}")


def collections_options_for_reading():
    collections_options = db.list_collection_names()
    options_text = "\n".join([f"{i + 1}.{collection}" for i, collection in enumerate(collections_options)])
    collection_name = tk.simpledialog.askstring("Choose",
                                                f"Please write the number of the collection that you want to read: \n {options_text} ")
    if collection_name:
        try:
            # Converting the user's input to an index
            index = int(collection_name) - 1
            if 0 <= index < len(collections_options):
                selected_collection = collections_options[index]
                read_all_data(db, selected_collection)
        except ValueError:
            messagebox.showinfo("Wrong format", "Invalid input. Please enter a number.")


def read_all_data(database, collection_name):
    try:
        # Access the specified collection
        collection = database[collection_name]

        # Using find method to find everything
        result = collection.find()

        new_window = Toplevel(window)
        new_window.title("Results of collection data")

        # iterating through the documents and printing them
        text_widget = scrolledtext.ScrolledText(new_window, wrap=tk.WORD, font=("Arial", 18), spacing1=10 )
        text_widget.grid(row=0, column=1)
        for document in result:
            text_widget.insert(tk.END, str(document) + "\n")

    except Exception as e:
        messagebox.showinfo("Error!", f"Could not read all data: {e}")

def filter_options():
    collections_options = db.list_collection_names()
    options_text = "\n".join([f"{i + 1}.{collection}" for i, collection in enumerate(collections_options)])
    collection_name = tk.simpledialog.askstring("Choose",
                                                f"Please write the number of the collection that you want to filter data from: \n {options_text} ")
    if collection_name:
        try:
            # Converting the user's input to an index
            index = int(collection_name) - 1
            if 0 <= index < len(collections_options):
                selected_collection = collections_options[index]
                filter_data = tk.simpledialog.askstring("Filter", "Please specify part of the data that you want to filter in the key : value format")
                if filter_data:
                    pairs = filter_data.split(",")

                    data_entries = {}
                    for pair in pairs:
                        key, value = pair.split(":")

                        find_queries_containing_filter(db, selected_collection, key.strip(), value.strip())

        except ValueError:
            messagebox.showinfo("Wrong format", "Invalid input. Please enter a number.")


def find_queries_containing_filter(database, collection_name, key, value):
    try:
        # Access the collection first
        collection = database[collection_name]

        # define the query to find results containing the searched item
        query = {key : value}

        # Use the find method to get matching documents
        cursor = collection.find(query)

        # convert your cursor to a list to freely operate over it
        result = list(cursor)

        # # print the matching documents
        # for document in result:
        #     print(document)

        new_window = Toplevel(window)
        new_window.title("Results of Filtered Data")

        # iterating through the documents and printing them
        text_widget = scrolledtext.ScrolledText(new_window, wrap=tk.WORD, font=("Arial", 18), spacing1=10)
        text_widget.grid(row=0, column=1)
        for document in result:
            text_widget.insert(tk.END, str(document) + "\n")

        return result
    except Exception as e:
        print(f"Error finding: {e}")


def update_data_by_id(database, collection_name, record_id, key, value):
    try:
        # Access the specified collection
        collection = database[collection_name]

        # define the query to find the document by its ID
        query = {"_id": record_id}

        # Use the update_one method to update the specific field
        result = collection.update_one(query, {"$set": {key : value}})

        # Check for success
        if result.matched_count == 1:
            print(f"Successfully updated the movie for record with ID {record_id}!")
        else:
            print("No such record exists")

    except errors.PyMongoError as e:
        print(f"Error: {e}")

def delete_options():
    collections_options = db.list_collection_names()
    options_text = "\n".join([f"{i + 1}.{collection}" for i, collection in enumerate(collections_options)])
    collection_name = tk.simpledialog.askstring("Choose",
                                                f"Please write the number of the collection that you want to delete data from: \n {options_text} ")
    if collection_name:
        try:
            # Converting the user's input to an index
            index = int(collection_name) - 1
            if 0 <= index < len(collections_options):
                selected_collection = collections_options[index]
                filter_data = tk.simpledialog.askstring("Filter",
                                                        "Please specify part of the data that you want to delete by in the key : value format")
                if filter_data:
                    pairs = filter_data.split(",")

                    data_entries = {}
                    for pair in pairs:
                        key, value = pair.split(":")

                        delete_record_by_name(db, selected_collection, key.strip(), value.strip())
        except ValueError as e:
            tk.messagebox.showinfo("Invalid Option", "That option is invalid.")

def delete_record_by_name(database, collection_name, key, value):
    try:
        collection = database[collection_name]

        # defining the query to find doc by its ID
        query = {key : value}

        # Use delete_many method to delete the document
        result = collection.delete_many(query)

        if result.deleted_count >= 1:
            tk.messagebox.showinfo("SUCCESS",f"Successfully deleted {result.deleted_count} record(s) that contains {key} : {value}")
        else:
            tk.messagebox.showinfo("Deletion Failed", f"No such filter {key} : {value} found in the records")

    except errors.PyMongoError as e:
        print(f"Error deleting: {e}")


def update_options():
    collections_options = db.list_collection_names()
    options_text = "\n".join([f"{i + 1}.{collection}" for i, collection in enumerate(collections_options)])
    collection_name = tk.simpledialog.askstring("Choose",
                                                f"Please write the number of the collection that you want to update data of: \n {options_text} ")
    if collection_name:
        try:
            # Converting the user's input to an index
            index = int(collection_name) - 1
            if 0 <= index < len(collections_options):
                selected_collection = collections_options[index]
                filter_data = tk.simpledialog.askstring("Filter",
                                                        "Please specify a filter to find the data that you want to update in the key : value format")
                result = ""
                res_id = ""
                if filter_data:
                    pairs = filter_data.split(",")

                    data_entries = {}
                    for pair in pairs:
                        key, value = pair.split(":")

                        result = find_queries_containing_filter(db, selected_collection, key.strip(), value.strip())
                        res_id = result[0]["_id"]

                    new_info = filter_data = tk.simpledialog.askstring("Update",
                                                        "Please specify the update that you want to do in the key : value format")

                    if new_info:
                        pairs = new_info.split(",")

                        data_entries = {}
                        for pair in pairs:
                            key, value = pair.split(":")
                            update_data_by_id(db, selected_collection, res_id, key.strip(), value.strip())


        except ValueError as e:
            messagebox.showinfo("Invalid", "Invalid option. Please try again.")

# # inserting some dummy data into the Movies database
#for data in TVshow_database:
   #insert_into_collection(db, "TV show", data)


window = Tk()
window.title("Personal Movie Review Database")

heading = Label(text="Welcome to the Movie Review Database. Please choose one of the following: ",
                font=("Arial", 18, "bold"))
heading.grid(row=0, column=1)

create_collection_btn = tk.Button(text="Create a Collection", font=("Times New Roman", 14, "bold"),
                                  command=user_prompt_creation)
create_collection_btn.grid(row=1, column=1, columnspan=2)

insert_into_collection_btn = tk.Button(text="Insert into a collection", font=("Times New Roman", 14, "bold"),
                                  command=collections_options)
insert_into_collection_btn.grid(row=2, column=1, columnspan=2)

read_all_data_btn = tk.Button(text="Read all data in a collection", font=("Times New Roman", 14, "bold"),
                                  command=collections_options_for_reading)
read_all_data_btn.grid(row=3, column=1, columnspan=2)

filter_data_btn = tk.Button(text="Filter data from a collection", font=("Times New Roman", 14, "bold"),
                                  command=filter_options)
filter_data_btn.grid(row=4, column=1, columnspan=2)

delete_data_btn = tk.Button(text="Delete data", font=("Times New Roman", 14, "bold"),
                                  command=delete_options)
delete_data_btn.grid(row=5, column=1, columnspan=2)

update_data_btn = tk.Button(text="Update data", font=("Times New Roman", 14, "bold"),
                                  command=update_options)
update_data_btn.grid(row=6, column=1, columnspan=2)

window.mainloop()