TVshow_database = [
  {
    "title": "Stranger Things",
    "genre": "Science Fiction",
    "release_year": 2016,
    "rating": 8.7,
    "description": "A group of kids in a small town uncover supernatural mysteries and face government conspiracies."
  },
  {
    "title": "Breaking Bad",
    "genre": "Crime",
    "release_year": 2008,
    "rating": 9.5,
    "description": "A high school chemistry teacher turned methamphetamine manufacturer navigates the criminal underworld."
  },
  {
    "title": "Game of Thrones",
    "genre": "Fantasy",
    "release_year": 2011,
    "rating": 9.3,
    "description": "Noble families vie for control of the Iron Throne in the mythical land of Westeros."
  },
  {
    "title": "The Mandalorian",
    "genre": "Action",
    "release_year": 2019,
    "rating": 8.8,
    "description": "A lone bounty hunter navigates the outer reaches of the galaxy in the Star Wars universe."
  },
  {
    "title": "Friends",
    "genre": "Comedy",
    "release_year": 1994,
    "rating": 8.9,
    "description": "The lives, relationships, and comedic adventures of a group of friends living in New York City."
  },
  {
    "title": "The Crown",
    "genre": "Drama",
    "release_year": 2016,
    "rating": 8.7,
    "description": "A historical drama that chronicles the reign of Queen Elizabeth II and the events that shaped the second half of the 20th century."
  },
  {
    "title": "The Simpsons",
    "genre": "Animation",
    "release_year": 1989,
    "rating": 8.6,
    "description": "The satirical adventures of the Simpson family in the fictional town of Springfield."
  },
  {
    "title": "Sherlock",
    "genre": "Crime",
    "release_year": 2010,
    "rating": 9.1,
    "description": "A modern adaptation of Arthur Conan Doyle's detective stories, featuring the brilliant detective Sherlock Holmes."
  },
  {
    "title": "Black Mirror",
    "genre": "Drama",
    "release_year": 2011,
    "rating": 8.8,
    "description": "An anthology series that explores the dark and often dystopian aspects of modern society and technology."
  },
  {
    "title": "The Office",
    "genre": "Comedy",
    "release_year": 2005,
    "rating": 8.9,
    "description": "A mockumentary-style sitcom that follows the daily lives of office employees at the Scranton branch of the Dunder Mifflin Paper Company."
  },
  {
    "title": "Westworld",
    "genre": "Science Fiction",
    "release_year": 2016,
    "rating": 8.6,
    "description": "In a futuristic theme park, guests experience adventures with lifelike android hosts, blurring the lines between reality and artificial intelligence."
  },
  {
    "title": "The Witcher",
    "genre": "Fantasy",
    "release_year": 2019,
    "rating": 8.2,
    "description": "A monster hunter navigates a world filled with magic, political intrigue, and dangerous creatures."
  },
  {
    "title": "Fleabag",
    "genre": "Comedy",
    "release_year": 2016,
    "rating": 8.7,
    "description": "A witty and emotionally raw comedy-drama that follows the life and struggles of a young woman navigating love, family, and grief in London."
  },
  {
    "title": "The Umbrella Academy",
    "genre": "Action",
    "release_year": 2019,
    "rating": 8.0,
    "description": "A dysfunctional family of adopted superhero siblings reunites to solve the mystery of their father's death and prevent an impending apocalypse."
  },
  {
    "title": "Breaking Bad",
    "genre": "Crime",
    "release_year": 2008,
    "rating": 9.5,
    "description": "A high school chemistry teacher turned methamphetamine manufacturer navigates the criminal underworld."
  },
  {
    "title": "The Mandalorian",
    "genre": "Action",
    "release_year": 2019,
    "rating": 8.8,
    "description": "A lone bounty hunter navigates the outer reaches of the galaxy in the Star Wars universe."
  }
]
